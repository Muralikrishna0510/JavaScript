console.time("This entire code took....");
console.log("first file of javascript");
console.log('Hello world');
console.log(`Murali's world`);
console.log(100+2);
console.log(100-2);
console.log(100*2);
console.log(100/2);
console.log(100%2);
console.log("100%2");
console.log([10,20,30,40,50]);
console.log([10,"hello world",30,40,50]);
console.log({course: 'fullstack', ratings: '5'});
console.table({course: 'fullstack', ratings: 5});
console.warn("This is a warning");
console.error("This is big error");
console.timeEnd("This entire code took....");
// console.clear();

// This is single line comment

/* This is
multiline
comment */