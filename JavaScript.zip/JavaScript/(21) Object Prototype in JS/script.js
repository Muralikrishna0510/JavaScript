// Object.prototype - The object.prototype has many build in methods & Properties such as tostring(), valueOf()and many more. Object.prototype object change through prototype chaining unless the properties and methods subject to those changes are overridden further along prototype chain.

// toString()

// valueOf()

// hasOwnProperty() - hasOwnProperty which will return a boolean value indicating whether an object contains the specified a property as a direct property of that object and not inherited through a prototype chain.

// isPropertyOf() - isPropertyOf function which returns boolean value indicating whether the specified object is in prototype chain of object. This method is called up on.

// propertyIsEnumerable() - which returns boolean value that indicate whether the specified property is Enumerable or not.

// toLocaleString() - Local string method which will return a string in the local format

// toString() 

// valueOf()

                                    //No Live server runned this is only explanation
function Motorcycle(){
    this.brand = 'Kawasaki',
    this.model = 'Ninja'
}

Motorcycle.prototype.motoGP = function(){
    console.log("Always wear a helmet while riding / racing motorcycle");
}

let bikes = new Motorcycle()
bikes.toString();

// bikes_proto_link