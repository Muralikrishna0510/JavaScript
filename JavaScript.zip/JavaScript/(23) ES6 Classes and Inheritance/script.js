// Using es6 classes
// ES6 supports class concept like any other Statically typed or object oriented language. So, object can be created out of a class in javascript as well.

// class SimpleDate{
//     constructor(givenYear, givenMonth, givenDay){
//         this.year = givenYear;
//         this.month = givenMonth;
//         this.day = givenDay;
//     }
//     addMonth(nMonths){

//     }

//     getMonth(){
//         return this.month;
//     }
// }

// Parent class
class car{
    constructor(givenName, givenYear){
        this.name = givenName;
        this.year = givenYear;
    }

    greet(){
        return `${this.name} says Hello`;
    }
}
// Child class
class Bike extends car{
    constructor(givenName, givenYear, givenSpeed){
        super(givenName,givenYear);      
        this.speed = givenSpeed;
    }
}

const bike1 = new Bike('Suzuki', 2022, 300);


const car1 = new car('BMW', '2022');

// call()

// The super() method in the constructor is used to access all parent’s properties and methods that are used by the derived class.
// We use the extends keyword to implement the inheritance in ES6. The class to be extended is called a base class or parent class. The class that extends the base class or parent class is called the derived class or child class. 