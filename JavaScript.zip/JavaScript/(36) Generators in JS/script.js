//We already know how to declare a normal function. So, the syntax of declaring the generator function is quite similar to traditional functions. We declare a generator function by using the * ( asterisk ) operator after the function keyword:
// Basic syntax to create a generator function
// function* name(params) {
//     yield 1;
//     yield 2;
// }


// The yield keyword pauses the generator function execution, and the value of the expression following the yield keyword is returned to the generator's caller. It acts as a generator-based version of the return keyword.

function* generator(){
    yield 1;
    yield 2;
}

let iterator = generator();
let result;

do {
    result = iterator.next();
    console.log(result);
} while (!result.done);