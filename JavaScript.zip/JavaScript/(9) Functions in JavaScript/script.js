
// Function - function is a set of statements that take inputs, do some specific computation, and produce output.
console.log("Functions in JavaScript");

// 1. Function Declaration - It declares a function with a function keyword. The function declaration must have a function name.
function display_message(msg) {
    console.log(msg);
}

display_message("Hello world");
display_message("JavaScript is the brain of a web page");



// 2. Function Expression - It is similar to a function declaration without the function name. Function expressions can be stored in a variable assignment. 
let add = function(a,b) {
    return a+b;
}

console.log(add(4,3));

// Example-2

function distance(speed, time) {
    let dist = speed*time;
    console.log(dist);
}

distance(10,5);