function fun1(){
    return new Promise(function(resolve,reject){
        setTimeout(function() {
            const error = false;
            if(!error){
                console.log("Promise operation is successful");
                resolve();
            }
            else{
                console.log("Promise operation was unsuccessful");
                reject("Mission failed");
            }
        }, 2000);
    })
}

fun1().then(function(){
    console.log("Thanks");
}).catch(function(error){              
    console.log("No thanks " + error);
})

// Promise - A promise is an object that represents the eventual completion(or failure) of an asynchronous operation and its resulting value.It helps to handle asynchronous operations in amore organised and readable way.

// catch() Method: It is invoked when a promise is either rejected or some error has occurred in execution. It is used as an Error Handler whenever at any step there is a chance of getting an error.