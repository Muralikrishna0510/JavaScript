console.log("Loops in JavaScript");

// for - for loop is used to iterate the elements/code block a fixed number of times. It is used if the number of the iteration is known.
for (let i = 1; i <= 100; i++) {
    console.log(i);
    if (i==90) {
        break;
    }
}

// forin - The for-in loop is used to iterate over the properties of an object. 
var person = {name: 'Sam', language: 'JavaScript', age: 19};

for (var i in person) {
    console.log(i + "=" + person[i]);
}

// foreach
const arr = [2,3,5];
let sum = 0;
arr.forEach(element => {
    // sum += element;
    sum = sum + element;
    console.log(sum);
});

// while -while loop is a control flow statement that repeatedly executes a block of code as long as a specified condition evaluates to true.
let x = 1, n = 100;
while (x<=n) {
    console.log(x);
    // x += 1;
    x++;
}

// Do while - A Do while loop  is a control statement in which the code is allowed to execute continuously based on a given boolean condition. It is like a repeating if statement.
let a = 1 , m=100;
do {
    console.log(a);
    a++;
} while (a<=m);

