// Literal Form: The literal form uses the construction of object literals that can be said as a collection of key-value pairs enclosed within a pair of curly braces.

// Objects created using object literal
var motorcycle = {
    brand: 'Kawasaki',
    model: 'Ninja',
    year: 1986
}
console.log(motorcycle);

// Constructed Form: The Constructed form uses either an object constructor function or the new keyword to create an empty object ad then adds properties to the object one by one.

// Objects created using constructor function
function MyMotorcycle(brand, model, year){
    this.brand = brand,
    this.model = model,
    this.year = year
}

// Create object
let bikes = new MyMotorcycle("Honda", "CBR", 2022);
console.log(bikes);

// Using New Keyword: This methodology uses the New keyword in front of any constructor method or any built-in constructor method ( such as Object, Date, String, etc) and creates a new instance of the following object by mounting it on memory.