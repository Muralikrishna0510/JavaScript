console.log("Callback functions tutorial");

// function fun1(){
//     console.log("Function1 is executing");
// }

// function fun2(){
//     console.log("Function2 is executing");
// }

// fun1();
// fun2();

function msg(str){
    setTimeout(function() {
        console.log("This how callback works");
    }, 5000);
}

msg();

// A callback is a function that is passed as an argument to another function, and is called after the main function has finished its execution. The main function is called with a callback function as its argument, and when the main function is finished, it calls the callback function to provide a result. Callbacks allow you to handle the results of an asynchronous operation in a non-blocking manner, which means that the program can continue to run while the operation is being executed.