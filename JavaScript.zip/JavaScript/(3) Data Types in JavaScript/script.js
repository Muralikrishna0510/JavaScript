// console.log("This is tutorial on data types");

// Primitive (stack)
/*
    1. String - Represent a sequence of characters enclosed in single or double quotes
    2. Numbers - Represents numerical values, such as `5`,`3.14`,`98`
    3. Boolean - Represent a logical entity and can have two values: true or false.
    4. Null - This type has only one value that is null.
    5. Undefined - A variable that has not been assigned a value is undefined.
*/

let name = "full stack2";
console.log("This course covers " + name + " web development");
console.log("The data type is "+ (typeof name));

let marks = 98;
console.log("Tom scored " + marks);
console.log("The data type is "+ (typeof marks));

let state = false;
console.log("This is best web development course " + state);
console.log("The data type is " + (typeof state));

let test1 = null;
console.log(test1);
console.log("The data type is " + (typeof test1));

let test2 = undefined;
console.log(test2);
console.log("The data type is " + (typeof test2));

// Reference (Heap / derived)

/*
    1. Arrays - Represents a collection of key-values. Array can be created using square brackets []
    2. Object Literals
    3. functions -Represents a block of resusable code that performs a specific task.
    4. Dates
*/

let arr = [10,undefined,"jack",false,null];
console.log(arr);
console.log("The data type is " + (typeof arr));

let students = {
    Jack: true,
    John: 96,
    Tom: 98
}
console.log(students);
console.table(students);
console.log("The data type is " + (typeof students));

