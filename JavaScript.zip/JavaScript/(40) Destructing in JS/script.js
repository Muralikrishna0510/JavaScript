// const person = {first: 'John', last: 'Anderton', country: 'USA'};
// // const first = person.first;
// // const second = person.second;

// const {first , second} = person;


var colors = ["Red", "Green", "Blue", "Yellow"];
var [a, b, ...c] = colors;
console.log(a);
console.log(b);
console.log(c);


// Destructing is breaking down a complex structure into simpler parts. In JavaScript, the complex structure is usually an array or an object. With the destructuring syntax, we can extract smaller fragments from arrays and objects. The destructuring syntax is also used for variable declaration or variable assignment. 