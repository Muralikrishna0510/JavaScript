const myInfo = {
    isMale: true,
    Bio: function(){
        console.log(`My name is ${this.name}. Am I male? ${this.isMale}`);
    } 
}

const mySelf = Object.create(myInfo);
mySelf.name = 'John';
mySelf.Bio();

// The Object.create() method creates a new object, using an existing object as the prototype of the newly created object.