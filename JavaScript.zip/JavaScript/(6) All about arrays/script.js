//Array - An array in JavaScript is a collection of elements enclosed in square brackets. Elements can be of any data type, including numbers, strings, and other arrays.

//Object - Objects in which we can store multiple values in a single variable.Objects are non-primitive type and these objects are like other variables. But the only difference is that an object holds multiple values and arrays and functions.

console.log("All about arrays and objects");

// 2 syntax to create Array
// let arr = [1,2,3,4,5,'John'];
let arr1 = new Array(1,2,3,4,5,'John');
console.log(arr1);

let arr2 = ['1st elem','2nd elem','3rd elem'];
console.log(arr2[0]);
console.log(arr2[1]);
console.log(arr2[arr2.length-1]);     //length - This method returns the number of elements in an array.

// indexOf()  -  Returns the index of the first occurrence of a value in an array, or -1 if it is not present.
let students = ['John', 'Jack', 'Sam', 'Tom'];
let a = students.indexOf('Jack');
console.log(a);

// sort() - This method is used to sort the values in descending order.
let age1 = [65, 56, 78, 87,19];
age1.sort();
console.log(age1);

// reverse() - This method is used to reverses the elements in an array in place
age1.reverse();
console.log(age1);

// concat() - This method is used to combine two or more arrays.
let alphabets = ['a','b','c'];
let numeric = [1,2,3];
let alphanumeric = alphabets.concat(numeric);
console.log(alphanumeric);

// push() - This method is used to add an element to the end of an array.
let city = ['Munich', 'New York', 'Cape Town'];
city.push('London');
console.log(city);


// pop() - This method is used to remove the last element of an array. 
city.pop();
console.log(city);

// shift() - This method is used to remove the first element of an array. 
city.shift();
console.log(city);

// unshift() - This method is used to add an element to the beginning of an array.
city.unshift('London');
console.log(city);


// Objects in JavaScript
// 2 Syntax to create an object
let user = new Object();
user.name = 'Jack';
user.age = 19;
user.language = 'JavaScript';
// let user = {
//     name: 'Jack',
//     age: 19,
//     language: 'JavaScript'
// }
console.log(user);