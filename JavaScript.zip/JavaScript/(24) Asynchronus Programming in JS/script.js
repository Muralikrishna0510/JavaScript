// Synchronus programming - Synchronus refers to code that is excuted in a sequential order, one after the other. It means that each line of code is excuted before moving on to the next one.

// function fun2(){
//     console.log("Fun2 is running");
// }

// function fun1(){
//     console.log("Fun1 is running");
//     fun2();
//     console.log("Fun1 has ended");
// }

// fun1();


// Asynchronus programming - Asynchronus refers to code that doen't run sequentailly. Instead , it allows multiple tasks to be excuted simultaneously.

function fun2(){
    setTimeout(function() {
        console.log("Fun2 is running");
    }, 5000);
}


function fun1(){
    console.log("Fun1 is running");
    fun2();
    console.log("Fun1 has ended");
}

fun1();
