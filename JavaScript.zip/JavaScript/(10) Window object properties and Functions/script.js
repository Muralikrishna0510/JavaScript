console.log("Manipulating webpages using JS");

// Window object properties
// let a = document;
// a = window.innerWidth; 
// a = innerHeight;
// a = location.toString(); To show the url of the web page
// // scrollX
// // scrollY
// // history.go(-1); To go back page (-1) or to go to front page(+1)
// console.log(a);

// Window Object methods
let b = document;
// window.alert("This is Alert");
// window.prompt("Enter your login ID");
// window.close(); - To close the web page
window.confirm("Are you sure you want to continue");