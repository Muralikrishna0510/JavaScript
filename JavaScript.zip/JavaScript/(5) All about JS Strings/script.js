
// String - A string in JavaScript is a sequence of characters enclosed in either single or double quotes
console.log("All about Strings in JavaScript");

let variable1 = "Web development";
let variable2 = "course";
// console.log(variable1+" "+variable2); //This method is used to concatenate (combine) two or more strings.

// let variable3 = variable1.concat(" ", variable2);
// console.log(variable3);

// variable1 = variable1.concat(' ', variable2);
// console.log(variable1);

let html = `<h1> Heading1 nejwj </h1> <p> Paragraph </p>`;
console.log(html);

console.log(html.length);             //This method returns the number of characters in a string.
console.log(html.toLowerCase());     //These methods are used to convert a string to uppercase or lowercase letters. 
console.log(html.toUpperCase());
console.log(html[3]);
console.log(html.indexOf('H'));       //This method is used to find the index of a specific character or substring in a string.
console.log(html.charAt(6));
console.log(html.endsWith('nejwj'));  //This method used to find the end of the string
console.log(html.includes('nejwj'));    
console.log(html.substring(1, 6));
console.log(html.slice(0, 10));         //This method is used to extract a portion of a string.
console.log(html.split('>'));
console.log(html.replace('Heading', 'Course'));  //This method is used to replace a specific character or substring in a string.

let item1 = 'Mac';
let item2 = 'ios';

let html2 = `<h1> Hi I use ${item1} and my friend uses ${item2} </h1> <h3> I love web development </h3>`;
console.log(html2);

document.body.innerHTML = html2;    //This is used to link the index.html file and add the text in the body and show the text in the web page